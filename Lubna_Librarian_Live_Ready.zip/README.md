# Lubna Librarian – College Library

This package is ready to publish as a static website.

## Included
- 188 imported library catalogue records
- Search and department filtering
- Responsive library interface
- Lubna Librarian branding

## Publish
Upload the contents of this folder to a GitHub repository and enable GitHub Pages.

## Important
This is the public catalogue version. A true multi-user librarian dashboard with secure PDF uploads, login, database, and Excel import requires a server/backend.
